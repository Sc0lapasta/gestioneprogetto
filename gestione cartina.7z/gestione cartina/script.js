let coordinate = [];

function caricaCoordinate() {
    $.ajax({
        url: 'https://raw.githubusercontent.com/Sc0lapasta/gestioneprogetto/refs/heads/main/giallo_piano_terra.json',
        success: function (fileJSON) {
            coordinate = JSON.parse(fileJSON);
            console.log(coordinate);

            carica();
        },
        error: function (error) {
            console.log("errore nel caricamento del file json", error);
        }
    });
}

function funzioneGenerica(area) {
    alert(area.alt + "inserire qui script a piacere");
}

function carica() {
    console.log(coordinate.length);
    for (let index = 0; index < coordinate.length; index++) {
        document.getElementById("area_inserimento").innerHTML +=
        '<area alt="' + coordinate[index]["alt"] + '" coords="' + coordinate[index]["coords"] + '" href="' + coordinate[index]["href"] 
        + '" shape="' + coordinate[index]["shape"] + '" onclick="funzioneGenerica(this)" />';   
    }
}